import random
from Functions import *

POPSIZE = 50
MUTPROB = .02
NUMSTEPS = 100

def generate():
    pop = []
    for i in range(POPSIZE):